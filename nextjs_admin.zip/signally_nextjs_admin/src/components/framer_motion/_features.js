import { domAnimation } from 'framer-motion';

export default domAnimation;
