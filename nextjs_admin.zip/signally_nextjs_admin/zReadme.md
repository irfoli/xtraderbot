# npm install

npm i --legacy-peer-deps

# check for updates

npm install -g npm-check-updates
npm-check-updates

# update package json

ncu -u

# install update

npm i

# All updates

npm-check-updates && ncu -u && npm i
